package com.simple.arrayexam;

public class Ex1 {

	public static void main(String[] args) {
		// 배열에 난수 채우기
		//길이가 10인 int 배열을 만들고, 
		//1~100 사이 난수로 채운 뒤 모든 값을 출력하시오.
		
		int[] exam = new int[10];
		
		

	}

}
