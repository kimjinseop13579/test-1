package com.simple.exam3;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// 자리수 합 구하기
		//사용자로부터 정수를 입력받아 각 자리수를 모두 더한 합을 출력하시오.
		//(예: 123 → 1+2+3=6)
		
		
		Scanner kbd = new Scanner(System.in);
		
	
		//데이터 입력
		int num = 0;
		System.out.println("숫자 입력:");
		num = kbd.nextInt();
		
		
		
		
		//데이터 처리
		
		
		//데이터 출력
		
		

	}

}
