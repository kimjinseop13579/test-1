package com.simple.exam3;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
