package com.simple.exam2;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// BMI 계산기

//간단한 계산기 (switch문 활용)
//두 수와 연산자(+,-,*,/)를 입력받아 계산 결과를 출력하세요.
		

		//데이터 입력
		int num1 = 0;
		int num2 = 0;
		
		String result = "";
		Scanner kbd = new Scanner(System.in);

		System.out.print("숫자1 :");
		num1 = kbd.nextInt();
		System.out.print("숫자2 :");
		num2 = kbd.nextInt();
		
		
		//데이터 처리
		
		
		
		
		//데이터 출력
		
		System.out.println("BMI");

	}

}
