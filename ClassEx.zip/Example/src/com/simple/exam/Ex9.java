package com.simple.exam;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {
		// 문자 판별하기

		// 문자를 입력받아 알파벳 대문자인지, 소문자인지, 숫자인지 판별하세요.

		// 데이터 입력
		int num = 0;
		String result = "";
		Scanner kbd = new Scanner(System.in);

		System.out.print("입력 :");
		num = kbd.nextInt();
		
		

		// 데이터 처리
		
		

		// 데이터 출력
		System.out.println("점수 :" + num);
		System.out.println("결과 :" + result);

	}

}
