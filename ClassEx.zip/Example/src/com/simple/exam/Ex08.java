package com.simple.exam;

import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		// 최댓값 구하기 (세 수)

//세 정수를 입력받아 가장 큰 수를 출력하세요.

		// 데이터 입력
		int num1 = 0;
		int num2 = 0;
		int num3 = 0;
		int max = 0;
		String result = "";
		Scanner kbd = new Scanner(System.in);

		System.out.print("숫자1입력 :");
		num1 = kbd.nextInt();

		System.out.print("숫자2입력 :");
		num2 = kbd.nextInt();

		System.out.print("숫자3입력 :");
		num3 = kbd.nextInt();
		
		
		// 데이터 처리
		// int max = (num1 > num2)? num1 : num2;
		
		max = num1;
		if( num2 > max ) {
			max = num2;
		}else if(num3 > max ){
			max = num3;
		}

		// 데이터 출력
		System.out.println("큰수 :" + max);

	}

}
