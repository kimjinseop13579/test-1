package com.simple.exam4;

public class Ex1 {

	public static void main(String[] args) {
		//  1부터 100까지 숫자 중 3의 배수와 5의 배수를 모두 출력하시오.
		//단, 3과 5의 공배수는 "FizzBuzz"라고 출력하시오.
		
		

	}

}
