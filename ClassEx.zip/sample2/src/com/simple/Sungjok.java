package com.simple;

public class Sungjok {

	public static void main(String[] args) {
		// 변수 준비
		int kor = 95;
		int mat = 50;
		
		//총점, 평균 계산
		int tot = kor+mat;
		double avg = tot / 2.0f;
		
		System.out.println("국어 :"+kor);
		System.out.println("수학 :"+mat);
		System.out.println("총점 :"+tot);
		System.out.println("평균 :"+avg);
		

	}

}
