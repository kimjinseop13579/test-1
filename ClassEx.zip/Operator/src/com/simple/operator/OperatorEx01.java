package com.simple.operator;

public class OperatorEx01 {

	public static void main(String[] args) {
		// 정수, 실수와 서로 계산
		int a = 10;
		//double b = 2.5;
		int b = 3;
		
		System.out.println("a+b="+(a+b));
		System.out.println("a-b="+(a-b));
		System.out.println("axb="+(a*b));
		System.out.println("a/b="+((double)(a)/b));
		System.out.println("a%+b="+(a%b));
				

	}

}
