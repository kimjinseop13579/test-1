package com.sample;

public class VarTest {

	public static void main(String[] args) {
	
		String name; //변수 선언
		int age; 
		
		
		name = "홍길동";
		age = 20;
		
		System.out.printf("이름:%s 나이:%d",name,age);
		
		System.out.println();
		
		name = "박보검";
		age = 35;
		
		System.out.printf("이름:%s 나이:%d",name,age);
		

	}

}
