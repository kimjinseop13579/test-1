package com.sample;

public class DataType3 {

	public static void main(String[] args) {
		byte num1 = 120;
		short num2 = 30000;
		double num3 = 123.5;
		long num4 = 12345645654444444L;
		
		char pass = '가'+10000;
		String pass1 = "통과"+1;
		
		System.out.println(pass);
		System.out.println(pass1);
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		
	 
		

	}

}
