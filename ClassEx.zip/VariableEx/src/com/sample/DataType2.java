package com.sample;

public class DataType2 {

	public static void main(String[] args) {
  
		float num1 = 21.5f;
		double num2 = 12.8;
		int num3 = 12;
				
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		
		System.out.println();
	 
		

	}

}
