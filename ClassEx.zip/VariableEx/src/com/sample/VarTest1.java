package com.sample;

public class VarTest1 {

	public static void main(String[] args) {
	
		String name; //변수 선언
		int age; 
		
		name = "홍길동";
		age = 25;
		System.out.print("이름:"+name);
		System.out.print("나이:"+age);
		
		System.out.println();
		
		name = "박보검";
		age = 35;
		System.out.println("이름:"+name);
		System.out.println("나이:"+age);
		

	}

}
